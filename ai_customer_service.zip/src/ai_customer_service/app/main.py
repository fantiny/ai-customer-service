from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from ..infrastructure.config import get_settings
from ..infrastructure.container import Container
from .routers import chat, health

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    settings = get_settings()
    container = Container(settings)
    logger.info("Initializing application container...")
    await container.initialize()
    app.state.container = container
    logger.info("Container ready. Application started.")
    yield
    logger.info("Shutting down...")
    await container.close()


def create_app() -> FastAPI:
    app = FastAPI(
        title="AI Customer Service",
        description="LangGraph-based e-commerce customer service system",
        version="0.1.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(health.router)
    app.include_router(chat.router)

    return app


app = create_app()
