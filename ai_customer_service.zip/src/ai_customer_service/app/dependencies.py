from __future__ import annotations

from fastapi import Header, HTTPException, Request, status

from ..infrastructure.container import Container
from ..use_cases.chat_service import ChatService


def get_container(request: Request) -> Container:
    return request.app.state.container


def get_chat_service(request: Request) -> ChatService:
    return get_container(request).chat_service


def get_current_user_id(x_user_id: str = Header(..., description="Authenticated user ID")) -> str:
    """Extract user ID from request header.

    In production, replace this with JWT validation middleware.
    """
    if not x_user_id or not x_user_id.strip():
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="X-User-ID header is required",
        )
    return x_user_id.strip()
