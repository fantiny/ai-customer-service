from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from .value_objects import MessageRole, OrderStatus


class Message(BaseModel):
    role: MessageRole
    content: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = Field(default_factory=dict)


class Conversation(BaseModel):
    thread_id: str
    user_id: str
    messages: list[Message] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class OrderItem(BaseModel):
    product_id: str
    name: str
    quantity: int
    unit_price: float


class Order(BaseModel):
    order_id: str
    user_id: str
    status: OrderStatus
    items: list[OrderItem]
    total: float
    created_at: datetime
    updated_at: datetime
    shipping_address: str = ""
    tracking_number: str = ""


class Document(BaseModel):
    doc_id: str
    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    score: float = 0.0


class OrderActionRequest(BaseModel):
    """Structured output from LLM for order action extraction."""

    action: str  # "get_status" | "cancel_order" | "initiate_refund" | "get_tracking"
    order_id: str
    extra: dict[str, Any] = Field(default_factory=dict)


class OrderActionResult(BaseModel):
    message: str
    order: Order | None = None
    success: bool = True
