from __future__ import annotations

import re

from langchain_core.messages import AIMessage
from langgraph.types import RunnableConfig

from ..state import CustomerServiceState

# Patterns that indicate prompt injection or malicious input
_BLOCKED_PATTERNS = [
    re.compile(p, re.IGNORECASE)
    for p in [
        r"ignore\s+(previous|all|above)\s+instructions",
        r"disregard\s+(your|the)\s+(system\s+)?prompt",
        r"you\s+are\s+now\s+(a\s+)?(?!a\s+customer)",  # role-hijack attempts
        r"<\s*script",
        r"eval\s*\(",
        r"__import__",
        r"prompt\s+injection",
    ]
]

MAX_INPUT_LENGTH = 2000


async def safety_check_node(
    state: CustomerServiceState, config: RunnableConfig
) -> dict:
    """First node in every graph run.

    1. Resets all ephemeral state fields.
    2. Validates the latest user message for safety violations and length.
    Returns early with a refusal message if checks fail.
    """
    # Always reset ephemeral fields at the start of each turn
    base_reset: dict = {
        "intent": "general",
        "retrieved_docs": [],
        "pending_action": {},
        "safety_passed": False,
    }

    messages = state.get("messages", [])
    if not messages:
        return {**base_reset, "safety_passed": True}

    latest = messages[-1]
    # Only check user messages
    if getattr(latest, "type", None) != "human":
        return {**base_reset, "safety_passed": True}

    content: str = latest.content or ""

    if len(content) > MAX_INPUT_LENGTH:
        return {
            **base_reset,
            "messages": [
                AIMessage(
                    content=f"您的消息过长（{len(content)} 字符），请将其控制在 {MAX_INPUT_LENGTH} 字符以内。"
                )
            ],
        }

    for pattern in _BLOCKED_PATTERNS:
        if pattern.search(content):
            return {
                **base_reset,
                "messages": [AIMessage(content="抱歉，我无法处理该请求。如有需要请联系人工客服。")],
            }

    return {**base_reset, "safety_passed": True}
