from __future__ import annotations

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.runnables import RunnableConfig

from ..state import CustomerServiceState

FAQ_SYSTEM_PROMPT = """你是一个专业的电商客服助手。请根据以下参考文档回答用户的问题。

参考文档：
{context}

回答要求：
- 直接回答用户问题，简洁明了
- 如果文档中没有相关信息，诚实告知用户并建议联系人工客服
- 使用友好、专业的语气
- 用中文回答"""


async def faq_node(state: CustomerServiceState, config: RunnableConfig) -> dict:
    """Retrieve relevant documents and generate an answer using RAG."""
    llm = config["configurable"]["llm"]
    retriever = config["configurable"]["retriever"]
    handler = config["configurable"].get("langfuse_handler")
    callbacks = [handler] if handler else []

    query = state["messages"][-1].content

    # Retrieve relevant documents
    docs = await retriever.retrieve(query)

    if docs:
        context = "\n\n".join(
            f"[文档 {i + 1}] {doc.content}" for i, doc in enumerate(docs)
        )
    else:
        context = "暂无相关文档"

    answer = await llm.ainvoke(
        [
            SystemMessage(content=FAQ_SYSTEM_PROMPT.format(context=context)),
            HumanMessage(content=query),
        ],
        config={"callbacks": callbacks},
    )

    return {
        "messages": [AIMessage(content=answer.content)],
        "retrieved_docs": [],  # clear after use to avoid token pollution
    }
