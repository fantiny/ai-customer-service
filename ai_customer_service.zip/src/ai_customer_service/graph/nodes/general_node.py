from __future__ import annotations

from langchain_core.messages import AIMessage, SystemMessage
from langchain_core.runnables import RunnableConfig

from ..state import CustomerServiceState

GENERAL_SYSTEM_PROMPT = """你是一个友好的电商客服助手。对于无法归类到订单或FAQ的消息，
请以礼貌、简短的方式回应，并引导用户告知具体需求。

如果用户表达感谢，礼貌回应即可。
如果用户有抱怨，表达理解和歉意，并说明可以帮助解决的范围（订单问题、商品咨询等）。
不要假装能处理超出能力范围的事情。"""


async def general_node(state: CustomerServiceState, config: RunnableConfig) -> dict:
    """Fallback node for out-of-scope or ambiguous requests."""
    llm = config["configurable"]["llm"]
    handler = config["configurable"].get("langfuse_handler")
    callbacks = [handler] if handler else []

    response = await llm.ainvoke(
        [SystemMessage(content=GENERAL_SYSTEM_PROMPT), *state["messages"][-3:]],
        config={"callbacks": callbacks},
    )
    return {"messages": [AIMessage(content=response.content)]}
