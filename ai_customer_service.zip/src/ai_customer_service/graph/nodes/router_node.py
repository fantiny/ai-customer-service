from __future__ import annotations

from typing import Literal

from langchain_core.messages import SystemMessage
from langchain_core.runnables import RunnableConfig
from pydantic import BaseModel, Field

from ..state import CustomerServiceState

ROUTER_SYSTEM_PROMPT = """你是一个电商客服意图分类器。分析用户最近的消息，将其分类为以下三种意图之一：

- faq: 用户询问关于退货政策、配送时间、支付方式、商品规格等一般性问题（知识库可以回答）
- order: 用户询问或操作具体订单（查询订单状态、取消订单、申请退款、查看物流）
- general: 无法归入以上两类的消息（闲聊、感谢、投诉意见、其他话题）

仅返回 JSON，不要添加任何解释。"""


class IntentClassification(BaseModel):
    intent: Literal["faq", "order", "general"] = Field(
        description="用户消息的意图分类"
    )
    confidence: float = Field(ge=0.0, le=1.0, description="分类置信度 0-1")


async def router_node(state: CustomerServiceState, config: RunnableConfig) -> dict:
    """Classify the user's intent using structured LLM output."""
    llm = config["configurable"]["llm"]
    handler = config["configurable"].get("langfuse_handler")
    callbacks = [handler] if handler else []

    classifier = llm.with_structured_output(IntentClassification)

    # Use last 3 messages for context (keeps token cost low)
    recent_messages = state["messages"][-3:]
    result: IntentClassification = await classifier.ainvoke(
        [SystemMessage(content=ROUTER_SYSTEM_PROMPT), *recent_messages],
        config={"callbacks": callbacks},
    )
    return {"intent": result.intent}
