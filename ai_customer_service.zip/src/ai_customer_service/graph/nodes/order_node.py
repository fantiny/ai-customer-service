from __future__ import annotations

from typing import Literal

from langchain_core.messages import AIMessage, SystemMessage
from langchain_core.runnables import RunnableConfig
from langgraph.types import interrupt
from pydantic import BaseModel, Field

from ...domain.entities import OrderActionRequest
from ...domain.exceptions import OrderNotFoundError, InvalidOrderActionError
from ..state import CustomerServiceState

# Actions requiring supervisor approval before execution
HIGH_RISK_ACTIONS = {"cancel_order", "initiate_refund"}

ORDER_EXTRACTION_PROMPT = """你是一个电商订单操作解析器。从用户消息中提取订单操作意图。

支持的操作：
- get_status: 查询订单状态
- cancel_order: 取消订单（高风险，需要审批）
- initiate_refund: 申请退款（高风险，需要审批）
- get_tracking: 查询物流信息

返回 JSON，如果无法确定订单号则 order_id 返回空字符串。"""


class OrderActionExtraction(BaseModel):
    action: Literal["get_status", "cancel_order", "initiate_refund", "get_tracking"] = Field(
        description="订单操作类型"
    )
    order_id: str = Field(description="订单号，无法识别时为空字符串")


async def order_node(state: CustomerServiceState, config: RunnableConfig) -> dict:
    """Handle order-related requests, with HITL interrupt for high-risk actions."""
    llm = config["configurable"]["llm"]
    order_service = config["configurable"]["order_service"]
    handler = config["configurable"].get("langfuse_handler")
    callbacks = [handler] if handler else []
    user_id: str = state.get("user_id", "")

    # Extract action and order ID from the conversation
    extractor = llm.with_structured_output(OrderActionExtraction)
    try:
        extraction: OrderActionExtraction = await extractor.ainvoke(
            [SystemMessage(content=ORDER_EXTRACTION_PROMPT), *state["messages"][-5:]],
            config={"callbacks": callbacks},
        )
    except Exception:
        return {
            "messages": [AIMessage(content="抱歉，我无法理解您的订单请求，请提供具体的订单号。")],
            "pending_action": {},
        }

    if not extraction.order_id:
        return {
            "messages": [
                AIMessage(content="请提供您的订单号，以便我为您查询。例如：「查询订单 #20240001 的状态」")
            ],
            "pending_action": {},
        }

    action_request = OrderActionRequest(
        action=extraction.action,
        order_id=extraction.order_id,
    )

    # For high-risk actions, suspend and wait for human approval
    if extraction.action in HIGH_RISK_ACTIONS:
        pending = {
            "action": extraction.action,
            "order_id": extraction.order_id,
            "user_id": user_id,
            "action_label": {
                "cancel_order": "取消订单",
                "initiate_refund": "申请退款",
            }.get(extraction.action, extraction.action),
        }
        # interrupt() raises GraphInterrupt — LangGraph captures it,
        # checkpoints state to Redis, and returns {"__interrupt__": [...]} to caller.
        # Execution resumes here after Command(resume=approval) is sent.
        approval: dict = interrupt(pending)

        if not approval.get("approved"):
            return {
                "messages": [AIMessage(content="操作已取消。如有其他需要请随时告知。")],
                "pending_action": {},
            }

    # Execute the action (safe actions run directly; approved high-risk actions resume here)
    try:
        result = await order_service.execute(action_request, user_id)
        return {
            "messages": [AIMessage(content=result.message)],
            "pending_action": {},
        }
    except OrderNotFoundError as e:
        return {
            "messages": [AIMessage(content=f"未找到订单 {e.order_id}，请确认订单号是否正确。")],
            "pending_action": {},
        }
    except InvalidOrderActionError as e:
        return {
            "messages": [AIMessage(content=str(e))],
            "pending_action": {},
        }
    except Exception:
        return {
            "messages": [AIMessage(content="处理订单请求时出现错误，请稍后重试或联系人工客服。")],
            "pending_action": {},
        }
