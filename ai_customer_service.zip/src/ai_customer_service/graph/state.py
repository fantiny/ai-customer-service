from __future__ import annotations

from typing import Annotated

from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages
from typing_extensions import TypedDict


class CustomerServiceState(TypedDict):
    # ── Durable (persisted by RedisSaver across turns) ─────────────────────
    messages: Annotated[list[AnyMessage], add_messages]
    thread_id: str
    user_id: str

    # ── Ephemeral (reset at turn start by safety_check_node) ───────────────
    intent: str              # "faq" | "order" | "general" | "blocked"
    retrieved_docs: list     # cleared after faq_node generates answer
    pending_action: dict     # HITL: populated before interrupt(), cleared after
    safety_passed: bool
