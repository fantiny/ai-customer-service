from __future__ import annotations

from langgraph.graph import END, StateGraph
from langgraph.graph.graph import CompiledGraph

from .edges import route_after_router, route_after_safety
from .nodes.faq_node import faq_node
from .nodes.general_node import general_node
from .nodes.order_node import order_node
from .nodes.router_node import router_node
from .nodes.safety_check_node import safety_check_node
from .state import CustomerServiceState


def build_graph(checkpointer: object) -> CompiledGraph:
    """Assemble and compile the customer service StateGraph.

    The graph is compiled once at startup and reused across all requests.
    Checkpointer (RedisSaver) provides per-thread state persistence.
    """
    builder: StateGraph = StateGraph(CustomerServiceState)

    # Register nodes
    builder.add_node("safety_check_node", safety_check_node)
    builder.add_node("router_node", router_node)
    builder.add_node("faq_node", faq_node)
    builder.add_node("order_node", order_node)
    builder.add_node("general_node", general_node)

    # Entry point
    builder.set_entry_point("safety_check_node")

    # Conditional edges
    builder.add_conditional_edges(
        "safety_check_node",
        route_after_safety,
        {"router_node": "router_node", END: END},
    )
    builder.add_conditional_edges(
        "router_node",
        route_after_router,
        {
            "faq_node": "faq_node",
            "order_node": "order_node",
            "general_node": "general_node",
            END: END,
        },
    )

    # Terminal edges
    builder.add_edge("faq_node", END)
    builder.add_edge("order_node", END)
    builder.add_edge("general_node", END)

    return builder.compile(checkpointer=checkpointer)
