from __future__ import annotations

from langgraph.graph import END

from .state import CustomerServiceState


def route_after_safety(state: CustomerServiceState) -> str:
    """Route to router if safety passed, otherwise end (refusal already in messages)."""
    if not state.get("safety_passed"):
        return END
    return "router_node"


def route_after_router(state: CustomerServiceState) -> str:
    """Route to the appropriate agent node based on classified intent."""
    intent = state.get("intent", "general")
    routing = {
        "faq": "faq_node",
        "order": "order_node",
        "general": "general_node",
        "blocked": END,
    }
    return routing.get(intent, "general_node")
