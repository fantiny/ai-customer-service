from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..domain.entities import Conversation, Document, Order, OrderActionRequest, OrderActionResult
from ..domain.value_objects import OrderStatus


class IVectorStore(ABC):
    @abstractmethod
    async def similarity_search(self, query: str, k: int) -> list[Document]:
        """Return top-k documents by semantic similarity to query."""

    @abstractmethod
    async def upsert(self, documents: list[Document], embeddings: list[list[float]]) -> None:
        """Insert or update documents with their pre-computed embeddings."""


class IOrderRepository(ABC):
    @abstractmethod
    async def get_by_id(self, order_id: str) -> Order:
        """Raise OrderNotFoundError if not found."""

    @abstractmethod
    async def get_by_user(self, user_id: str, limit: int = 10) -> list[Order]:
        """Return recent orders for a user."""

    @abstractmethod
    async def update_status(self, order_id: str, status: OrderStatus) -> Order:
        """Update order status and return the updated order."""

    @abstractmethod
    async def create(self, order: Order) -> Order:
        """Persist a new order."""


class IConversationRepository(ABC):
    @abstractmethod
    async def save(self, conversation: Conversation) -> None:
        """Persist or update a conversation record."""

    @abstractmethod
    async def get(self, thread_id: str) -> Conversation | None:
        """Return None if thread_id not found."""

    @abstractmethod
    async def delete(self, thread_id: str) -> None:
        """Remove a conversation record."""


class IOrderService(ABC):
    @abstractmethod
    async def execute(self, request: OrderActionRequest, user_id: str) -> OrderActionResult:
        """Execute the requested order action and return a result."""


class IEmbeddingClient(ABC):
    @abstractmethod
    async def aembed_query(self, text: str) -> list[float]:
        """Embed a single query string."""

    @abstractmethod
    async def aembed_documents(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of documents."""
