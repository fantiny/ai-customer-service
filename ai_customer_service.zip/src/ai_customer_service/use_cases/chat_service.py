from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any, Callable

from langchain_core.messages import AIMessage, HumanMessage

from ..adapters.observability.langfuse_handler import build_langfuse_handler
from ..domain.entities import Conversation
from ..infrastructure.config import Settings
from .interfaces import IConversationRepository

# Type alias: callable that returns the full LangGraph invocation config
GraphConfigFactory = Callable[[str, str, Any], dict]


@dataclass
class ChatResponse:
    thread_id: str
    reply: str | None
    status: str  # "complete" | "interrupted" | "error"
    pending_action: dict | None = None


class ChatService:
    """Orchestrates conversation flow via the compiled LangGraph.

    graph_config_factory is a callable(thread_id, user_id, langfuse_handler) -> dict
    that builds the full RunnableConfig passed to graph.ainvoke().
    This keeps ChatService decoupled from the Container.
    """

    def __init__(
        self,
        graph: Any,
        conv_repo: IConversationRepository,
        settings: Settings,
        graph_config_factory: GraphConfigFactory,
    ) -> None:
        self._graph = graph
        self._conv_repo = conv_repo
        self._settings = settings
        self._config_factory = graph_config_factory

    async def send_message(
        self, thread_id: str, user_id: str, message: str
    ) -> ChatResponse:
        handler = build_langfuse_handler(
            self._settings, session_id=thread_id, user_id=user_id
        )
        config = self._config_factory(thread_id, user_id, handler)

        result = await self._graph.ainvoke(
            {
                "messages": [HumanMessage(content=message)],
                "thread_id": thread_id,
                "user_id": user_id,
            },
            config=config,
        )
        return self._parse_result(result, thread_id)

    async def resume_hitl(
        self, thread_id: str, user_id: str, approval: dict
    ) -> ChatResponse:
        from langgraph.types import Command

        handler = build_langfuse_handler(
            self._settings,
            session_id=thread_id,
            user_id=user_id,
            trace_name="customer_service_hitl_resume",
        )
        config = self._config_factory(thread_id, user_id, handler)
        result = await self._graph.ainvoke(Command(resume=approval), config=config)
        return self._parse_result(result, thread_id)

    async def get_history(self, thread_id: str) -> Conversation | None:
        return await self._conv_repo.get(thread_id)

    @staticmethod
    def new_thread_id() -> str:
        return str(uuid.uuid4())

    @staticmethod
    def _parse_result(result: dict, thread_id: str) -> ChatResponse:
        if "__interrupt__" in result:
            interrupt_data = result["__interrupt__"]
            pending = interrupt_data[0].value if interrupt_data else {}
            return ChatResponse(
                thread_id=thread_id,
                reply=None,
                status="interrupted",
                pending_action=pending,
            )
        messages = result.get("messages", [])
        ai_messages = [m for m in messages if isinstance(m, AIMessage)]
        reply = ai_messages[-1].content if ai_messages else "无法处理您的请求，请稍后重试。"
        return ChatResponse(thread_id=thread_id, reply=reply, status="complete")
