from __future__ import annotations

from ..domain.entities import OrderActionRequest, OrderActionResult
from ..domain.exceptions import InvalidOrderActionError, OrderAccessDeniedError
from ..domain.value_objects import OrderStatus
from .interfaces import IOrderRepository


class OrderService:
    """Executes order actions after validation."""

    def __init__(self, repo: IOrderRepository) -> None:
        self._repo = repo

    async def execute(self, request: OrderActionRequest, user_id: str) -> OrderActionResult:
        action = request.action
        order_id = request.order_id

        if action == "get_status":
            return await self._get_status(order_id, user_id)
        if action == "get_tracking":
            return await self._get_tracking(order_id, user_id)
        if action == "cancel_order":
            return await self._cancel_order(order_id, user_id)
        if action == "initiate_refund":
            return await self._initiate_refund(order_id, user_id)

        raise InvalidOrderActionError(action, "unknown")

    async def _get_status(self, order_id: str, user_id: str) -> OrderActionResult:
        order = await self._repo.get_by_id(order_id)
        self._assert_owner(order, user_id)
        status_map = {
            OrderStatus.PENDING: "待确认",
            OrderStatus.CONFIRMED: "已确认，准备发货",
            OrderStatus.SHIPPED: "已发货",
            OrderStatus.DELIVERED: "已送达",
            OrderStatus.CANCELLED: "已取消",
            OrderStatus.REFUND_PENDING: "退款审核中",
            OrderStatus.REFUNDED: "已退款",
        }
        status_label = status_map.get(order.status, order.status.value)
        items_desc = "、".join(f"{item.name} x{item.quantity}" for item in order.items)
        return OrderActionResult(
            message=(
                f"订单 {order_id} 当前状态：**{status_label}**\n"
                f"商品：{items_desc}\n"
                f"订单总额：¥{order.total:.2f}"
            ),
            order=order,
        )

    async def _get_tracking(self, order_id: str, user_id: str) -> OrderActionResult:
        order = await self._repo.get_by_id(order_id)
        self._assert_owner(order, user_id)
        if order.status not in (OrderStatus.SHIPPED, OrderStatus.DELIVERED):
            return OrderActionResult(
                message=f"订单 {order_id} 尚未发货，无法查询物流信息。",
                order=order,
            )
        tracking = order.tracking_number or "暂无运单号"
        return OrderActionResult(
            message=f"订单 {order_id} 运单号：{tracking}",
            order=order,
        )

    async def _cancel_order(self, order_id: str, user_id: str) -> OrderActionResult:
        order = await self._repo.get_by_id(order_id)
        self._assert_owner(order, user_id)
        if order.status not in (OrderStatus.PENDING, OrderStatus.CONFIRMED):
            raise InvalidOrderActionError("cancel_order", order.status.value)
        updated = await self._repo.update_status(order_id, OrderStatus.CANCELLED)
        return OrderActionResult(
            message=f"订单 {order_id} 已成功取消。如需退款，款项将在 3-5 个工作日内原路退回。",
            order=updated,
        )

    async def _initiate_refund(self, order_id: str, user_id: str) -> OrderActionResult:
        order = await self._repo.get_by_id(order_id)
        self._assert_owner(order, user_id)
        if order.status not in (OrderStatus.DELIVERED, OrderStatus.CANCELLED):
            raise InvalidOrderActionError("initiate_refund", order.status.value)
        updated = await self._repo.update_status(order_id, OrderStatus.REFUND_PENDING)
        return OrderActionResult(
            message=(
                f"订单 {order_id} 退款申请已提交（¥{order.total:.2f}），"
                "审核通过后将在 3-5 个工作日内退回原支付账户。"
            ),
            order=updated,
        )

    @staticmethod
    def _assert_owner(order, user_id: str) -> None:
        if order.user_id != user_id:
            raise OrderAccessDeniedError(order.order_id, user_id)
