from __future__ import annotations

from ..adapters.retrieval.hybrid_retriever import HybridRetriever
from ..domain.entities import Document


class FAQService:
    """Retrieval service for the FAQ knowledge base."""

    def __init__(self, retriever: HybridRetriever) -> None:
        self._retriever = retriever

    async def retrieve(self, query: str) -> list[Document]:
        """Return top-k relevant documents for the given query."""
        return await self._retriever.retrieve(query)
