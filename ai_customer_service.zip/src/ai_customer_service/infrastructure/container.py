from __future__ import annotations

from typing import Any

import asyncpg
import redis.asyncio as aioredis

from ..adapters.llm.factory import LLMFactory
from ..adapters.observability.langfuse_handler import build_langfuse_handler
from ..adapters.repositories.conversation_repository import ConversationRepository
from ..adapters.repositories.order_repository import OrderRepository
from ..adapters.retrieval.bm25_retriever import BM25Retriever
from ..adapters.retrieval.hybrid_retriever import HybridRetriever
from ..adapters.retrieval.pgvector_store import PGVectorStore
from ..graph.builder import build_graph
from ..infrastructure.config import Settings
from ..infrastructure.database import create_db_pool
from ..infrastructure.redis_client import create_redis_pool
from ..use_cases.chat_service import ChatService
from ..use_cases.order_service import OrderService


class Container:
    """Manual dependency injection container.

    Initializes all components in dependency order at application startup.
    Provides a graph_config_factory so ChatService remains decoupled from Container.
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._db_pool: asyncpg.Pool | None = None
        self._redis: aioredis.Redis | None = None
        self._chat_service: ChatService | None = None
        self._llm: Any = None
        self._retriever: HybridRetriever | None = None
        self._order_service: OrderService | None = None
        self._graph: Any = None

    async def initialize(self) -> None:
        settings = self._settings

        # 1. Infrastructure connections
        self._db_pool = await create_db_pool(settings)
        self._redis = await create_redis_pool(settings)

        # 2. Checkpointer (Redis-backed)
        from langgraph.checkpoint.redis import AsyncRedisSaver
        self._checkpointer = AsyncRedisSaver(self._redis)
        await self._checkpointer.asetup()

        # 3. LLM (shared base instance; callbacks added per-request)
        self._llm = LLMFactory.build(settings)

        # 4. Embedding client
        embedding_client = LLMFactory.build_embedding_client(settings)

        # 5. Vector store
        vector_store = PGVectorStore(self._db_pool)

        # 6. BM25 (built from current corpus in DB)
        bm25 = await BM25Retriever.from_db(self._db_pool)

        # 7. Optional reranker
        reranker = None
        if settings.RERANKER_ENABLED:
            from ..adapters.retrieval.reranker import FlagReranker
            reranker = FlagReranker(settings.RERANKER_MODEL)

        # 8. Hybrid retriever
        self._retriever = HybridRetriever(
            vector_store=vector_store,
            bm25=bm25,
            embedding_client=embedding_client,
            reranker=reranker,
            k=settings.RETRIEVAL_K,
        )

        # 9. Repositories
        order_repo = OrderRepository(self._db_pool)
        conv_repo = ConversationRepository(self._db_pool)

        # 10. Use case services
        self._order_service = OrderService(order_repo)

        # 11. Compile graph
        self._graph = build_graph(self._checkpointer)

        # 12. Chat service (receives a config factory, not the container)
        self._chat_service = ChatService(
            graph=self._graph,
            conv_repo=conv_repo,
            settings=settings,
            graph_config_factory=self._make_graph_config,
        )

    def _make_graph_config(
        self, thread_id: str, user_id: str, langfuse_handler: Any
    ) -> dict:
        """Build the RunnableConfig passed to graph.ainvoke() for each request."""
        return {
            "configurable": {
                "thread_id": thread_id,
                "user_id": user_id,
                "llm": self._llm,
                "retriever": self._retriever,
                "order_service": self._order_service,
                "langfuse_handler": langfuse_handler,
            }
        }

    @property
    def chat_service(self) -> ChatService:
        assert self._chat_service is not None, "Container not initialized"
        return self._chat_service

    async def close(self) -> None:
        if self._db_pool:
            await self._db_pool.close()
        if self._redis:
            await self._redis.aclose()
