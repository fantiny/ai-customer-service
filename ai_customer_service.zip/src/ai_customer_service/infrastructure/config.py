from __future__ import annotations

from functools import lru_cache
from typing import Any, Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", env_file_encoding="utf-8")

    # --- LLM ---
    LLM_PROVIDER: Literal["openai", "openai_compat", "anthropic", "ollama"] = "openai_compat"
    LLM_MODEL: str = "deepseek-chat"
    LLM_API_KEY: str = ""        # For openai / openai_compat providers
    LLM_BASE_URL: str = ""       # Custom endpoint for openai_compat (e.g. DeepSeek, vLLM)
    LLM_TEMPERATURE: float = 0.0
    ANTHROPIC_API_KEY: str = ""  # For anthropic provider
    OLLAMA_BASE_URL: str = "http://localhost:11434"  # For ollama provider

    # --- Embedding (OpenAI-compatible) ---
    EMBEDDING_MODEL: str = "text-embedding-3-small"
    EMBEDDING_API_KEY: str = ""  # Falls back to LLM_API_KEY when empty
    EMBEDDING_BASE_URL: str = "" # Falls back to LLM_BASE_URL when empty

    # --- PostgreSQL ---
    POSTGRES_URL: str = "postgresql+asyncpg://csuser:cspass@localhost:5432/customer_service"
    POSTGRES_POOL_SIZE: int = Field(default=10, ge=1, le=50)

    # Sync URL for langgraph-checkpoint-postgres (uses psycopg3, not asyncpg)
    @property
    def POSTGRES_SYNC_URL(self) -> str:
        return self.POSTGRES_URL.replace("postgresql+asyncpg://", "postgresql://")

    # --- Redis ---
    REDIS_URL: str = "redis://localhost:6379/0"

    # --- Langfuse ---
    LANGFUSE_ENABLED: bool = True
    LANGFUSE_PUBLIC_KEY: str = ""
    LANGFUSE_SECRET_KEY: str = ""
    LANGFUSE_HOST: str = "https://cloud.langfuse.com"

    # --- RAG ---
    RERANKER_ENABLED: bool = False
    RERANKER_MODEL: str = "BAAI/bge-reranker-base"
    RETRIEVAL_K: int = Field(default=5, ge=1, le=20)

    # --- App ---
    APP_ENV: Literal["development", "staging", "production"] = "development"
    LOG_LEVEL: str = "INFO"

    # ------------------------------------------------------------------
    # Resolved connection kwargs — all provider-specific logic lives here
    # so LLMFactory stays a thin dispatcher with no conditional branching.
    # ------------------------------------------------------------------

    def llm_kwargs(self) -> dict[str, Any]:
        """Return the exact keyword arguments to pass to the LangChain chat model."""
        kwargs: dict[str, Any] = {
            "model": self.LLM_MODEL,
            "temperature": self.LLM_TEMPERATURE,
        }
        if self.LLM_PROVIDER in ("openai", "openai_compat"):
            kwargs["api_key"] = self.LLM_API_KEY or "placeholder"
            if self.LLM_BASE_URL:
                kwargs["base_url"] = self.LLM_BASE_URL
        elif self.LLM_PROVIDER == "anthropic":
            kwargs["api_key"] = self.ANTHROPIC_API_KEY
        elif self.LLM_PROVIDER == "ollama":
            kwargs["base_url"] = self.OLLAMA_BASE_URL
        return kwargs

    def embedding_kwargs(self) -> dict[str, Any]:
        """Return the exact keyword arguments to pass to the embedding client."""
        return {
            "model": self.EMBEDDING_MODEL,
            "api_key": self.EMBEDDING_API_KEY or self.LLM_API_KEY or "placeholder",
            "base_url": self.EMBEDDING_BASE_URL or self.LLM_BASE_URL or None,
        }


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
