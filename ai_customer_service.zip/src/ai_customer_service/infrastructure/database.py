from __future__ import annotations

import asyncpg

from .config import Settings


async def create_db_pool(settings: Settings) -> asyncpg.Pool:
    # asyncpg expects a standard postgresql:// URL, not postgresql+asyncpg://
    url = settings.POSTGRES_URL.replace("postgresql+asyncpg://", "postgresql://")
    pool: asyncpg.Pool = await asyncpg.create_pool(
        dsn=url,
        min_size=2,
        max_size=settings.POSTGRES_POOL_SIZE,
        command_timeout=30,
    )
    return pool
