from __future__ import annotations

import json

import asyncpg

from ...domain.entities import Conversation, Message
from ...domain.value_objects import MessageRole
from ...use_cases.interfaces import IConversationRepository


class ConversationRepository(IConversationRepository):
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def save(self, conversation: Conversation) -> None:
        messages_json = json.dumps(
            [
                {
                    "role": m.role.value,
                    "content": m.content,
                    "timestamp": m.timestamp.isoformat(),
                    "metadata": m.metadata,
                }
                for m in conversation.messages
            ]
        )
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO conversations (thread_id, user_id, messages, created_at, updated_at)
                VALUES ($1, $2, $3, $4, NOW())
                ON CONFLICT (thread_id) DO UPDATE
                  SET messages = EXCLUDED.messages,
                      updated_at = NOW()
                """,
                conversation.thread_id,
                conversation.user_id,
                messages_json,
                conversation.created_at,
            )

    async def get(self, thread_id: str) -> Conversation | None:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM conversations WHERE thread_id = $1", thread_id
            )
        if not row:
            return None
        messages_data = json.loads(row["messages"])
        from datetime import datetime

        return Conversation(
            thread_id=row["thread_id"],
            user_id=row["user_id"],
            messages=[
                Message(
                    role=MessageRole(m["role"]),
                    content=m["content"],
                    timestamp=datetime.fromisoformat(m["timestamp"]),
                    metadata=m.get("metadata", {}),
                )
                for m in messages_data
            ],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    async def delete(self, thread_id: str) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                "DELETE FROM conversations WHERE thread_id = $1", thread_id
            )
