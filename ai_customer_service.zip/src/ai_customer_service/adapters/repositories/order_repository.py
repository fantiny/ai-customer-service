from __future__ import annotations

import json
from datetime import datetime

import asyncpg

from ...domain.entities import Order, OrderItem
from ...domain.exceptions import OrderNotFoundError
from ...domain.value_objects import OrderStatus
from ...use_cases.interfaces import IOrderRepository


class OrderRepository(IOrderRepository):
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def get_by_id(self, order_id: str) -> Order:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM orders WHERE order_id = $1", order_id
            )
        if not row:
            raise OrderNotFoundError(order_id)
        return self._row_to_order(row)

    async def get_by_user(self, user_id: str, limit: int = 10) -> list[Order]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM orders WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2",
                user_id,
                limit,
            )
        return [self._row_to_order(r) for r in rows]

    async def update_status(self, order_id: str, status: OrderStatus) -> Order:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                UPDATE orders SET status = $1, updated_at = NOW()
                WHERE order_id = $2
                RETURNING *
                """,
                status.value,
                order_id,
            )
        if not row:
            raise OrderNotFoundError(order_id)
        return self._row_to_order(row)

    async def create(self, order: Order) -> Order:
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO orders
                  (order_id, user_id, status, items, total, shipping_address, tracking_number,
                   created_at, updated_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
                """,
                order.order_id,
                order.user_id,
                order.status.value,
                json.dumps([item.model_dump() for item in order.items]),
                order.total,
                order.shipping_address,
                order.tracking_number,
                order.created_at,
                order.updated_at,
            )
        return order

    def _row_to_order(self, row: asyncpg.Record) -> Order:
        items_data = json.loads(row["items"]) if isinstance(row["items"], str) else row["items"]
        return Order(
            order_id=row["order_id"],
            user_id=row["user_id"],
            status=OrderStatus(row["status"]),
            items=[OrderItem(**item) for item in items_data],
            total=float(row["total"]),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            shipping_address=row.get("shipping_address", ""),
            tracking_number=row.get("tracking_number", ""),
        )
