from __future__ import annotations

from typing import Any

from langchain_core.language_models import BaseChatModel

from ...infrastructure.config import Settings


class LLMFactory:
    """Thin dispatcher: reads resolved connection kwargs from Settings and
    instantiates the appropriate LangChain chat model.

    All provider-specific connection logic lives in Settings.llm_kwargs()
    and Settings.embedding_kwargs() — not here.
    """

    @classmethod
    def build(cls, settings: Settings, callbacks: list[Any] | None = None) -> BaseChatModel:
        provider = settings.LLM_PROVIDER
        kwargs = settings.llm_kwargs()
        if callbacks:
            kwargs["callbacks"] = callbacks

        if provider in ("openai", "openai_compat"):
            from langchain_openai import ChatOpenAI
            return ChatOpenAI(**kwargs)

        if provider == "anthropic":
            from langchain_anthropic import ChatAnthropic
            return ChatAnthropic(**kwargs)

        if provider == "ollama":
            from langchain_ollama import ChatOllama
            return ChatOllama(**kwargs)

        raise ValueError(
            f"Unknown LLM provider: '{provider}'. "
            "Choose from: openai, openai_compat, anthropic, ollama"
        )

    @classmethod
    def build_embedding_client(cls, settings: Settings) -> Any:
        from langchain_openai import OpenAIEmbeddings
        return OpenAIEmbeddings(**settings.embedding_kwargs())
