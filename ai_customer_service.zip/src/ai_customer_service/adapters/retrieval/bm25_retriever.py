from __future__ import annotations

import asyncpg
from rank_bm25 import BM25Okapi

from ...domain.entities import Document


class BM25Retriever:
    """In-memory BM25 retriever built from the FAQ document corpus."""

    def __init__(self, documents: list[Document]) -> None:
        self._documents = documents
        tokenized = [doc.content.lower().split() for doc in documents]
        self._bm25 = BM25Okapi(tokenized) if tokenized else None

    @classmethod
    async def from_db(cls, pool: asyncpg.Pool) -> "BM25Retriever":
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT doc_id, content, metadata FROM faq_documents")
        docs = [
            Document(doc_id=row["doc_id"], content=row["content"])
            for row in rows
        ]
        return cls(docs)

    def search(self, query: str, k: int) -> list[Document]:
        if not self._bm25 or not self._documents:
            return []
        tokens = query.lower().split()
        scores = self._bm25.get_scores(tokens)
        ranked = sorted(
            zip(scores, self._documents), key=lambda x: x[0], reverse=True
        )
        return [
            Document(doc_id=doc.doc_id, content=doc.content, metadata=doc.metadata, score=score)
            for score, doc in ranked[:k]
            if score > 0
        ]

    def rebuild(self, documents: list[Document]) -> None:
        """Hot-reload the index when documents are added."""
        self._documents = documents
        tokenized = [doc.content.lower().split() for doc in documents]
        self._bm25 = BM25Okapi(tokenized) if tokenized else None
