from __future__ import annotations

import json
import uuid
from typing import Any

import asyncpg

from ...domain.entities import Document
from ...use_cases.interfaces import IVectorStore


class PGVectorStore(IVectorStore):
    """Stores and retrieves documents using pgvector cosine similarity."""

    def __init__(self, pool: asyncpg.Pool, embedding_dim: int = 1536) -> None:
        self._pool = pool
        self._embedding_dim = embedding_dim

    async def similarity_search(self, query_embedding: list[float], k: int) -> list[Document]:  # type: ignore[override]
        """Search by pre-computed embedding vector."""
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT doc_id, content, metadata,
                       1 - (embedding <=> $1::vector) AS score
                FROM faq_documents
                ORDER BY embedding <=> $1::vector
                LIMIT $2
                """,
                str(query_embedding),
                k,
            )
        return [
            Document(
                doc_id=row["doc_id"],
                content=row["content"],
                metadata=json.loads(row["metadata"]) if row["metadata"] else {},
                score=float(row["score"]),
            )
            for row in rows
        ]

    async def similarity_search_by_text(
        self, query_embedding: list[float], k: int
    ) -> list[Document]:
        return await self.similarity_search(query_embedding, k)

    async def upsert(self, documents: list[Document], embeddings: list[list[float]]) -> None:
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                for doc, emb in zip(documents, embeddings):
                    await conn.execute(
                        """
                        INSERT INTO faq_documents (doc_id, content, metadata, embedding)
                        VALUES ($1, $2, $3, $4::vector)
                        ON CONFLICT (doc_id) DO UPDATE
                          SET content = EXCLUDED.content,
                              metadata = EXCLUDED.metadata,
                              embedding = EXCLUDED.embedding,
                              updated_at = NOW()
                        """,
                        doc.doc_id or str(uuid.uuid4()),
                        doc.content,
                        json.dumps(doc.metadata),
                        str(emb),
                    )
