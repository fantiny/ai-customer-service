from __future__ import annotations

import asyncio
from typing import Any

from ...domain.entities import Document
from .bm25_retriever import BM25Retriever
from .pgvector_store import PGVectorStore
from .reranker import FlagReranker


class HybridRetriever:
    """Combines BM25 + vector search via Reciprocal Rank Fusion (RRF).

    RRF score: score(d) = Σ 1 / (rank_i + k) across result lists,
    where k=60 is the standard smoothing constant.
    """

    RRF_K = 60

    def __init__(
        self,
        vector_store: PGVectorStore,
        bm25: BM25Retriever,
        embedding_client: Any,
        reranker: FlagReranker | None = None,
        k: int = 5,
    ) -> None:
        self._vector_store = vector_store
        self._bm25 = bm25
        self._embedding_client = embedding_client
        self._reranker = reranker
        self._k = k

    async def retrieve(self, query: str) -> list[Document]:
        fetch_k = self._k * 2

        # Embed query once, then run BM25 and vector search concurrently
        query_embedding = await self._embedding_client.aembed_query(query)
        bm25_res, vector_res = await asyncio.gather(
            asyncio.to_thread(self._bm25.search, query, fetch_k),
            self._vector_store.similarity_search(query_embedding, fetch_k),
        )

        fused = self._rrf_merge(bm25_res, vector_res)[: self._k]

        if self._reranker:
            fused = await asyncio.to_thread(self._reranker.rerank, query, fused)

        return fused

    def _rrf_merge(
        self, list_a: list[Document], list_b: list[Document]
    ) -> list[Document]:
        scores: dict[str, float] = {}
        seen: dict[str, Document] = {}

        for rank, doc in enumerate(list_a):
            scores[doc.doc_id] = scores.get(doc.doc_id, 0.0) + 1.0 / (rank + self.RRF_K)
            seen[doc.doc_id] = doc

        for rank, doc in enumerate(list_b):
            scores[doc.doc_id] = scores.get(doc.doc_id, 0.0) + 1.0 / (rank + self.RRF_K)
            seen[doc.doc_id] = doc

        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        result = []
        for doc_id, rrf_score in ranked:
            d = seen[doc_id]
            result.append(
                Document(
                    doc_id=d.doc_id,
                    content=d.content,
                    metadata=d.metadata,
                    score=rrf_score,
                )
            )
        return result
