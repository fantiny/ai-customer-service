from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.messages import AIMessage, HumanMessage

from ai_customer_service.domain.entities import Document
from ai_customer_service.graph.nodes.faq_node import faq_node
from ai_customer_service.graph.state import CustomerServiceState


def _make_state(message: str) -> CustomerServiceState:
    return CustomerServiceState(
        messages=[HumanMessage(content=message)],
        thread_id="t1",
        user_id="u1",
        intent="faq",
        retrieved_docs=[],
        pending_action={},
        safety_passed=True,
    )


@pytest.mark.asyncio
async def test_faq_node_retrieves_and_generates(mock_llm, mock_retriever):
    mock_llm.ainvoke = AsyncMock(return_value=AIMessage(content="7天无理由退货。"))
    state = _make_state("退货政策是什么？")
    config = {
        "configurable": {
            "llm": mock_llm,
            "retriever": mock_retriever,
            "langfuse_handler": None,
        }
    }

    result = await faq_node(state, config=config)

    mock_retriever.retrieve.assert_awaited_once_with("退货政策是什么？")
    assert len(result["messages"]) == 1
    assert isinstance(result["messages"][0], AIMessage)
    assert result["retrieved_docs"] == []  # cleared after use


@pytest.mark.asyncio
async def test_faq_node_handles_empty_retrieval(mock_llm):
    retriever = MagicMock()
    retriever.retrieve = AsyncMock(return_value=[])
    mock_llm.ainvoke = AsyncMock(return_value=AIMessage(content="暂无相关信息"))

    state = _make_state("这是一个冷门问题")
    config = {
        "configurable": {
            "llm": mock_llm,
            "retriever": retriever,
            "langfuse_handler": None,
        }
    }

    result = await faq_node(state, config=config)
    assert isinstance(result["messages"][0], AIMessage)
