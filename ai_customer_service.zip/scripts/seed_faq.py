#!/usr/bin/env python3
"""Seed the FAQ knowledge base with e-commerce FAQ documents.

Run after migrate_db.py:
    python scripts/seed_faq.py
"""

from __future__ import annotations

import asyncio
import sys
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ai_customer_service.adapters.llm.factory import LLMFactory
from ai_customer_service.adapters.retrieval.pgvector_store import PGVectorStore
from ai_customer_service.domain.entities import Document
from ai_customer_service.infrastructure.config import get_settings
from ai_customer_service.infrastructure.database import create_db_pool

FAQ_DOCUMENTS = [
    {
        "title": "退货政策",
        "content": (
            "我们支持7天无理由退货。商品需保持原包装，未使用状态。"
            "退货流程：1）在订单页面申请退货；2）填写退货原因；3）打印退货快递单；"
            "4）将商品寄回；5）我们收到商品后3-5个工作日内原路退款。"
            "以下商品不支持退货：数字产品、已开封的食品、定制商品。"
        ),
    },
    {
        "title": "配送时间与物流",
        "content": (
            "标准配送：下单后1-3个工作日发货，全国配送3-7天到达。"
            "加急配送：额外支付运费，24小时内发货，1-3天到达（部分地区除外）。"
            "免费配送：订单满99元免邮。偏远地区（新疆、西藏等）可能需要额外运费。"
            "可在订单页面查看物流实时状态。"
        ),
    },
    {
        "title": "支付方式",
        "content": (
            "支持的支付方式：微信支付、支付宝、银联、信用卡（Visa/Mastercard）、"
            "花呗分期（3/6/12期）、京东白条。"
            "所有支付均通过安全加密通道，不会保存您的支付信息。"
            "支付遇到问题请联系客服或拨打400热线。"
        ),
    },
    {
        "title": "商品质量保证",
        "content": (
            "所有商品均为正品，提供品牌官方质保。"
            "电子产品：1年质保（人为损坏除外）。"
            "服装鞋帽：180天质量问题包换。"
            "如收到损坏或质量问题商品，请在收货后48小时内联系客服，提供照片证明，"
            "我们将免费补发或全额退款。"
        ),
    },
    {
        "title": "会员积分规则",
        "content": (
            "消费积分：每消费1元获得1积分。积分可用于抵扣现金（100积分=1元）。"
            "积分有效期：自获得之日起24个月。"
            "会员等级：普通会员（0-999积分）、银卡（1000-4999积分）、"
            "金卡（5000-19999积分）、钻石（20000积分以上）。"
            "高级会员享受专属折扣、优先客服、生日礼券等特权。"
        ),
    },
    {
        "title": "发票与开票",
        "content": (
            "支持电子发票和纸质发票。下单时可选择发票类型并填写抬头。"
            "电子发票：下单后24小时内发送至邮箱。"
            "纸质发票：随商品一同寄出。"
            "企业发票需提供企业名称、税号、地址电话、开户行信息。"
            "如需补开发票，请在订单完成后30天内申请。"
        ),
    },
    {
        "title": "客服联系方式",
        "content": (
            "在线客服：工作日9:00-22:00，周末10:00-20:00（本AI客服全天候）。"
            "人工客服电话：400-xxx-xxxx（工作日9:00-18:00）。"
            "邮件：support@example.com（24小时内回复）。"
            "紧急问题（涉及支付安全）请直接拨打热线，AI客服无法处理。"
        ),
    },
    {
        "title": "换货流程",
        "content": (
            "支持7天换货（尺码不合、颜色不符等）。"
            "换货步骤：1）申请换货并说明原因；2）填写新商品规格；"
            "3）等待审核（1-2个工作日）；4）审核通过后寄回原商品；"
            "5）收到后3个工作日内发出新商品。"
            "换货产生的运费：非质量问题换货，买家承担来回运费；质量问题，平台承担。"
        ),
    },
    {
        "title": "预售商品规则",
        "content": (
            "预售商品需先支付定金（通常为总价10%-30%），余款在发货前支付。"
            "预售期间不支持退款定金（除商家违约外）。"
            "预售商品的发货时间以商品页面标注为准，通常为1-30天。"
            "预售商品不参与普通促销活动，但可使用会员积分抵扣。"
        ),
    },
    {
        "title": "促销活动与优惠券",
        "content": (
            "优惠券类型：满减券（满X元减Y元）、折扣券（X折）、免邮券。"
            "优惠券获取：注册礼、生日礼、活动领取、客服补偿。"
            "使用限制：每单限用一张，部分商品不适用（已标注）。"
            "双十一、618等大促期间有额外优惠，请关注官方公告。"
            "优惠券不可转让，不可提现，过期作废。"
        ),
    },
]


async def seed() -> None:
    settings = get_settings()
    pool = await create_db_pool(settings)
    embedding_client = LLMFactory.build_embedding_client(settings)
    vector_store = PGVectorStore(pool)

    print(f"Seeding {len(FAQ_DOCUMENTS)} FAQ documents...")
    documents = [
        Document(
            doc_id=str(uuid.uuid5(uuid.NAMESPACE_DNS, d["title"])),
            content=f"【{d['title']}】\n{d['content']}",
            metadata={"title": d["title"]},
        )
        for d in FAQ_DOCUMENTS
    ]

    texts = [doc.content for doc in documents]
    print("Generating embeddings...")
    embeddings = await embedding_client.aembed_documents(texts)

    await vector_store.upsert(documents, embeddings)
    print(f"✓ Seeded {len(documents)} documents into faq_documents table.")
    await pool.close()


if __name__ == "__main__":
    asyncio.run(seed())
