#!/usr/bin/env python3
"""Database migration script.

Run once before starting the application:
    python scripts/migrate_db.py
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import asyncpg

from ai_customer_service.infrastructure.config import get_settings

DDL = """
-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- FAQ knowledge base with vector embeddings
CREATE TABLE IF NOT EXISTS faq_documents (
    doc_id       TEXT PRIMARY KEY,
    content      TEXT NOT NULL,
    metadata     JSONB DEFAULT '{}',
    embedding    vector(1536),           -- dimension matches text-embedding-3-small
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- HNSW index for fast approximate nearest-neighbor search
CREATE INDEX IF NOT EXISTS faq_documents_embedding_idx
    ON faq_documents USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);

-- Orders table for e-commerce scenarios
CREATE TABLE IF NOT EXISTS orders (
    order_id         TEXT PRIMARY KEY,
    user_id          TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'pending',
    items            JSONB NOT NULL DEFAULT '[]',
    total            NUMERIC(10, 2) NOT NULL DEFAULT 0,
    shipping_address TEXT DEFAULT '',
    tracking_number  TEXT DEFAULT '',
    created_at       TIMESTAMPTZ DEFAULT NOW(),
    updated_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS orders_user_id_idx ON orders (user_id);
CREATE INDEX IF NOT EXISTS orders_status_idx  ON orders (status);

-- Conversation metadata (LangGraph checkpoints live in Redis;
-- this table stores summary metadata for history queries)
CREATE TABLE IF NOT EXISTS conversations (
    thread_id   TEXT PRIMARY KEY,
    user_id     TEXT NOT NULL,
    messages    JSONB NOT NULL DEFAULT '[]',
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS conversations_user_id_idx ON conversations (user_id);
"""


async def run_migrations() -> None:
    settings = get_settings()
    dsn = settings.POSTGRES_URL.replace("postgresql+asyncpg://", "postgresql://")
    print(f"Connecting to: {dsn.split('@')[-1]}")  # log host only, not credentials

    conn = await asyncpg.connect(dsn=dsn)
    try:
        await conn.execute(DDL)
        print("✓ Migrations applied successfully.")
    finally:
        await conn.close()


if __name__ == "__main__":
    asyncio.run(run_migrations())
